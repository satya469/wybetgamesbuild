self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3e63f76778a92b628c9dc8f6831f21ea",
    "url": "/index.html"
  },
  {
    "revision": "0424ec4fc2e404c2fd49",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "21409235920efabdbc05",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "c65da062aae165d199ae",
    "url": "/static/css/14.db940404.chunk.css"
  },
  {
    "revision": "b31b338c7c717cac7f88",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "19fc89af67100269b1e4",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "0424ec4fc2e404c2fd49",
    "url": "/static/js/0.3a18a110.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.3a18a110.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fc6ae765a2b1f9117950",
    "url": "/static/js/1.3d63dcb2.chunk.js"
  },
  {
    "revision": "21409235920efabdbc05",
    "url": "/static/js/12.0b255168.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.0b255168.chunk.js.LICENSE.txt"
  },
  {
    "revision": "071a1cbf0de92da1843c",
    "url": "/static/js/13.542ac27e.chunk.js"
  },
  {
    "revision": "c65da062aae165d199ae",
    "url": "/static/js/14.34fc1a06.chunk.js"
  },
  {
    "revision": "b31b338c7c717cac7f88",
    "url": "/static/js/15.6959a325.chunk.js"
  },
  {
    "revision": "64d4a7ab606444bbcc4b",
    "url": "/static/js/16.65cfc70d.chunk.js"
  },
  {
    "revision": "72108a90a75d1ec35a46",
    "url": "/static/js/17.bad8dd3c.chunk.js"
  },
  {
    "revision": "5acc7094e5cbca04447c",
    "url": "/static/js/18.748aa77a.chunk.js"
  },
  {
    "revision": "413c590bd599aade8789",
    "url": "/static/js/19.22c80817.chunk.js"
  },
  {
    "revision": "4489f296e050805180b3",
    "url": "/static/js/2.04c65c44.chunk.js"
  },
  {
    "revision": "717c84be0f389fdfc09c",
    "url": "/static/js/20.45dbe818.chunk.js"
  },
  {
    "revision": "42a5696a1dfefc7ab30c",
    "url": "/static/js/21.0b7afb93.chunk.js"
  },
  {
    "revision": "a1c8bb8e56baaac10934",
    "url": "/static/js/22.93a41650.chunk.js"
  },
  {
    "revision": "401d819557f3bd79b575",
    "url": "/static/js/23.79a9548a.chunk.js"
  },
  {
    "revision": "93c80bf8e401c6281731",
    "url": "/static/js/24.d83f6091.chunk.js"
  },
  {
    "revision": "9228f96c1d8a556a6e73",
    "url": "/static/js/25.4ad385b8.chunk.js"
  },
  {
    "revision": "41592e4baf91866ea62a",
    "url": "/static/js/26.f158f1dd.chunk.js"
  },
  {
    "revision": "bb4753f903c3c177c2c0",
    "url": "/static/js/27.52dba32e.chunk.js"
  },
  {
    "revision": "5f421d1cd322026dbf2e",
    "url": "/static/js/28.00d59a31.chunk.js"
  },
  {
    "revision": "075bbc3176002484a580",
    "url": "/static/js/29.932e98b5.chunk.js"
  },
  {
    "revision": "2841a0d13b12d7e5c607",
    "url": "/static/js/3.b5304605.chunk.js"
  },
  {
    "revision": "aef3ea8b0dbf20db70d2",
    "url": "/static/js/30.a7710e16.chunk.js"
  },
  {
    "revision": "47499354c5d16c20ca3b",
    "url": "/static/js/31.3e8532d7.chunk.js"
  },
  {
    "revision": "ed8fc9813aedb4ec6bcb",
    "url": "/static/js/32.6a588e79.chunk.js"
  },
  {
    "revision": "b427bdf2b61668d9fd65",
    "url": "/static/js/33.a1090415.chunk.js"
  },
  {
    "revision": "b40d23e82ee5c38fe733",
    "url": "/static/js/34.9139cd11.chunk.js"
  },
  {
    "revision": "b7cb7a4ac7dc95cde64c",
    "url": "/static/js/35.051f934b.chunk.js"
  },
  {
    "revision": "79bc7c3a04b453d01535",
    "url": "/static/js/36.b75cd2a3.chunk.js"
  },
  {
    "revision": "e0fd2a07a0809f9e056f",
    "url": "/static/js/37.3069aad1.chunk.js"
  },
  {
    "revision": "1b9767ac212b83246952",
    "url": "/static/js/38.9c5a68a5.chunk.js"
  },
  {
    "revision": "29b762dfb764a4f4bbd7",
    "url": "/static/js/39.31d2c9b4.chunk.js"
  },
  {
    "revision": "03844dab87f22e762de0",
    "url": "/static/js/4.446a288b.chunk.js"
  },
  {
    "revision": "d2a654cce849e2e4e1d8",
    "url": "/static/js/40.3ebf4a2d.chunk.js"
  },
  {
    "revision": "961b4e6a6d47f1b1e1e8",
    "url": "/static/js/41.83ec5c0e.chunk.js"
  },
  {
    "revision": "8eb66d8d087e7fad2bd0",
    "url": "/static/js/42.bf5f97f6.chunk.js"
  },
  {
    "revision": "b34198eb05dfbadd4c98",
    "url": "/static/js/43.43575ef3.chunk.js"
  },
  {
    "revision": "821d037a2920f12ad67b",
    "url": "/static/js/44.f8bc92af.chunk.js"
  },
  {
    "revision": "ae5f940324fb68bc11b9",
    "url": "/static/js/45.5fb8a67f.chunk.js"
  },
  {
    "revision": "a90a96d4387d380be770",
    "url": "/static/js/46.15d91d1a.chunk.js"
  },
  {
    "revision": "c812771151de67feb513",
    "url": "/static/js/47.149daf34.chunk.js"
  },
  {
    "revision": "2c41200eee057cd5b56e",
    "url": "/static/js/48.0a57c666.chunk.js"
  },
  {
    "revision": "f84c7240dfd792d4549c",
    "url": "/static/js/49.34c52903.chunk.js"
  },
  {
    "revision": "5ca470ce1b6c82f075b4",
    "url": "/static/js/5.09ae0a8c.chunk.js"
  },
  {
    "revision": "06211599ba610f209ccf",
    "url": "/static/js/50.a68e9a57.chunk.js"
  },
  {
    "revision": "cd336cf736b41584f0bf",
    "url": "/static/js/51.d986402d.chunk.js"
  },
  {
    "revision": "5cfa6678d74104cbe586",
    "url": "/static/js/52.e024b920.chunk.js"
  },
  {
    "revision": "895daab8b0c59b389d52",
    "url": "/static/js/53.37a920bc.chunk.js"
  },
  {
    "revision": "62a0b14cb39647865ff0",
    "url": "/static/js/54.c263cad2.chunk.js"
  },
  {
    "revision": "6f606b85770df4a43898",
    "url": "/static/js/55.db1c1100.chunk.js"
  },
  {
    "revision": "51047524081f15993887",
    "url": "/static/js/56.40c9d514.chunk.js"
  },
  {
    "revision": "65ab9743f866134d1549",
    "url": "/static/js/57.35d19e77.chunk.js"
  },
  {
    "revision": "bcf50e270295b6e90205",
    "url": "/static/js/58.82e18543.chunk.js"
  },
  {
    "revision": "acbb01beb778d12cf58c",
    "url": "/static/js/59.bea9a478.chunk.js"
  },
  {
    "revision": "aba208f2978bed049857",
    "url": "/static/js/6.6b674eea.chunk.js"
  },
  {
    "revision": "af3c7598743f9199066c",
    "url": "/static/js/60.159438b1.chunk.js"
  },
  {
    "revision": "2e55f75e37712dc2de4b",
    "url": "/static/js/61.8873f2b1.chunk.js"
  },
  {
    "revision": "81bf50a9ab076c78cd3c",
    "url": "/static/js/62.b47b4671.chunk.js"
  },
  {
    "revision": "687014eca39a82d7f9de",
    "url": "/static/js/63.99211429.chunk.js"
  },
  {
    "revision": "e6d684e351a67d71f6e7",
    "url": "/static/js/64.3bde305f.chunk.js"
  },
  {
    "revision": "0ea0d33077cd7293c359",
    "url": "/static/js/65.4637d497.chunk.js"
  },
  {
    "revision": "495b78096c36c93e1f6a",
    "url": "/static/js/66.94677c0e.chunk.js"
  },
  {
    "revision": "1a77bfeb68cc45bd8e78",
    "url": "/static/js/67.b973b441.chunk.js"
  },
  {
    "revision": "260cf3d7df30bf3292fe",
    "url": "/static/js/68.31f07a8d.chunk.js"
  },
  {
    "revision": "6d3f187cb26dd1ff681e",
    "url": "/static/js/69.f3170a05.chunk.js"
  },
  {
    "revision": "1cd81b592917e2affbcf",
    "url": "/static/js/7.55fc6f06.chunk.js"
  },
  {
    "revision": "ca1786892d07d50cff19",
    "url": "/static/js/70.0f9cb216.chunk.js"
  },
  {
    "revision": "f9c09eb1d59243970216",
    "url": "/static/js/71.d1620102.chunk.js"
  },
  {
    "revision": "3110faab601651a3dc69",
    "url": "/static/js/72.f42f5223.chunk.js"
  },
  {
    "revision": "c683a0f59f96ecd4a92a",
    "url": "/static/js/73.4f281fe4.chunk.js"
  },
  {
    "revision": "7d2bcb8cb8bfe842c615",
    "url": "/static/js/74.a5fc4ee4.chunk.js"
  },
  {
    "revision": "fd57ce243efd30111151",
    "url": "/static/js/75.349bab78.chunk.js"
  },
  {
    "revision": "6c64852b3495b82db00c",
    "url": "/static/js/76.82bc34ad.chunk.js"
  },
  {
    "revision": "35cf2f8c23fd7faca5de",
    "url": "/static/js/77.c609044c.chunk.js"
  },
  {
    "revision": "ef67afb148bc314ade58",
    "url": "/static/js/78.2acb0ac2.chunk.js"
  },
  {
    "revision": "e29e4ddc30f5635b3ba5",
    "url": "/static/js/79.f0b537d1.chunk.js"
  },
  {
    "revision": "38ec7a745032fcbaf457",
    "url": "/static/js/8.ab40f493.chunk.js"
  },
  {
    "revision": "b74cb95d8416acc7fc94",
    "url": "/static/js/80.ceb662fe.chunk.js"
  },
  {
    "revision": "b5ac77ec5c3b83f9fd6d",
    "url": "/static/js/9.ff37c3d2.chunk.js"
  },
  {
    "revision": "19fc89af67100269b1e4",
    "url": "/static/js/main.ac97ffa4.chunk.js"
  },
  {
    "revision": "432998e667b82dadab06",
    "url": "/static/js/runtime-main.53b948a6.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);