self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a0f20ed48464b220a0bb6f32185a9b8b",
    "url": "/index.html"
  },
  {
    "revision": "d53e5bff10317d47eb17",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "fc43352fdb07578c3b47",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "20b184e6c61921dcec9c",
    "url": "/static/css/13.6e24b372.chunk.css"
  },
  {
    "revision": "b6024c1857bbc71c11bb",
    "url": "/static/css/14.834d426e.chunk.css"
  },
  {
    "revision": "171d404af0bbd2564a5b",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "d53e5bff10317d47eb17",
    "url": "/static/js/0.3c1caad7.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.3c1caad7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7393e8fa3c034c81a2e6",
    "url": "/static/js/1.70aede60.chunk.js"
  },
  {
    "revision": "fc43352fdb07578c3b47",
    "url": "/static/js/12.1d6dc013.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.1d6dc013.chunk.js.LICENSE.txt"
  },
  {
    "revision": "20b184e6c61921dcec9c",
    "url": "/static/js/13.6302631f.chunk.js"
  },
  {
    "revision": "b6024c1857bbc71c11bb",
    "url": "/static/js/14.4f788773.chunk.js"
  },
  {
    "revision": "98eea33caf3a2c96212b",
    "url": "/static/js/15.f0b22471.chunk.js"
  },
  {
    "revision": "6cb2f7c13067238933ad",
    "url": "/static/js/16.910b6b41.chunk.js"
  },
  {
    "revision": "f7b587bab1f84a6c9855",
    "url": "/static/js/17.79a35dea.chunk.js"
  },
  {
    "revision": "c2ae7dddfa4ee5d5d38f",
    "url": "/static/js/18.bfbbff57.chunk.js"
  },
  {
    "revision": "e9f726164ccf64e63393",
    "url": "/static/js/19.833600cb.chunk.js"
  },
  {
    "revision": "f5781217156e2d85331f",
    "url": "/static/js/2.a36b4876.chunk.js"
  },
  {
    "revision": "f9cf89eb887b336f82b0",
    "url": "/static/js/20.12b1ea38.chunk.js"
  },
  {
    "revision": "61020ea7e4556b9662fa",
    "url": "/static/js/21.aa002bfc.chunk.js"
  },
  {
    "revision": "817a081162bf2bd0505b",
    "url": "/static/js/22.c126429f.chunk.js"
  },
  {
    "revision": "770b285e5354b206a21c",
    "url": "/static/js/23.37bc0e9c.chunk.js"
  },
  {
    "revision": "a5a907cff2aebf99db16",
    "url": "/static/js/24.36d36d5a.chunk.js"
  },
  {
    "revision": "f1d22b292c8a50d1f5dd",
    "url": "/static/js/25.048e99f4.chunk.js"
  },
  {
    "revision": "959e9ca211ad444763f1",
    "url": "/static/js/26.cf5623f7.chunk.js"
  },
  {
    "revision": "d8466d6d31bba1bc740c",
    "url": "/static/js/27.85fd0f27.chunk.js"
  },
  {
    "revision": "720cc1f7ca22c37b270a",
    "url": "/static/js/28.4b8fede5.chunk.js"
  },
  {
    "revision": "12bfb43de5da7e4dc578",
    "url": "/static/js/29.fdc77183.chunk.js"
  },
  {
    "revision": "8e24fe6451d9415e5614",
    "url": "/static/js/3.fb2ef35c.chunk.js"
  },
  {
    "revision": "4a372b712a8a9788ace0",
    "url": "/static/js/30.c733266e.chunk.js"
  },
  {
    "revision": "c5ea3e8c2fd8c36b71e9",
    "url": "/static/js/31.4069ffa6.chunk.js"
  },
  {
    "revision": "971d7e347638b6c4f4b2",
    "url": "/static/js/32.02bf7aa7.chunk.js"
  },
  {
    "revision": "a5c83d73f9f45f7057c7",
    "url": "/static/js/33.197ae75f.chunk.js"
  },
  {
    "revision": "478bbf5800b2c0c408a5",
    "url": "/static/js/34.09ddad1f.chunk.js"
  },
  {
    "revision": "098acc47ef57d794b615",
    "url": "/static/js/35.ab7a3ee8.chunk.js"
  },
  {
    "revision": "96e825ae488257ba4920",
    "url": "/static/js/36.e2f5d2e4.chunk.js"
  },
  {
    "revision": "e855502ed88b551bd468",
    "url": "/static/js/37.4b67547d.chunk.js"
  },
  {
    "revision": "43a9357f8385b03c7117",
    "url": "/static/js/38.58da2886.chunk.js"
  },
  {
    "revision": "6e1ebc35269d450da4e7",
    "url": "/static/js/39.b095b9d8.chunk.js"
  },
  {
    "revision": "33f9c68dc641528f8138",
    "url": "/static/js/4.3b3cac40.chunk.js"
  },
  {
    "revision": "6fe4600cce6aec3a33b3",
    "url": "/static/js/40.fff53e8c.chunk.js"
  },
  {
    "revision": "5dc97a999af71511cd8a",
    "url": "/static/js/41.160135cc.chunk.js"
  },
  {
    "revision": "32fccd0ba70d67bf9b7c",
    "url": "/static/js/42.282b008a.chunk.js"
  },
  {
    "revision": "24dfe5dbd766a8e3d0b0",
    "url": "/static/js/43.890c2f76.chunk.js"
  },
  {
    "revision": "b94b1399a9201705848f",
    "url": "/static/js/44.8dcad10c.chunk.js"
  },
  {
    "revision": "003045d61ebcd1685d40",
    "url": "/static/js/45.99ce32ad.chunk.js"
  },
  {
    "revision": "441d9fd21c5cbab351b5",
    "url": "/static/js/46.c386cf8b.chunk.js"
  },
  {
    "revision": "139cf490911bb26fbd4b",
    "url": "/static/js/47.30a3daed.chunk.js"
  },
  {
    "revision": "b927446872efee687e3f",
    "url": "/static/js/48.dddc8e98.chunk.js"
  },
  {
    "revision": "0ea486b42767d42bf83c",
    "url": "/static/js/49.24e1334d.chunk.js"
  },
  {
    "revision": "57931d45430c13cd4643",
    "url": "/static/js/5.76f4aeb5.chunk.js"
  },
  {
    "revision": "a5a15dbcad9c62f87421",
    "url": "/static/js/50.cf344f1c.chunk.js"
  },
  {
    "revision": "1c98d321bc2bc73fdc26",
    "url": "/static/js/51.8f05a62a.chunk.js"
  },
  {
    "revision": "5e32691d23b036cd4c3a",
    "url": "/static/js/52.559afbb6.chunk.js"
  },
  {
    "revision": "ef805e82146a2cf95286",
    "url": "/static/js/53.00e05f78.chunk.js"
  },
  {
    "revision": "a028c2f0b7b315e28485",
    "url": "/static/js/54.88ff04e7.chunk.js"
  },
  {
    "revision": "41831edde617b9f54b1f",
    "url": "/static/js/55.f0119847.chunk.js"
  },
  {
    "revision": "77f3838e326d029b8574",
    "url": "/static/js/56.3106a3b7.chunk.js"
  },
  {
    "revision": "7e9bc6294897da6d9dd2",
    "url": "/static/js/57.b41d6b3a.chunk.js"
  },
  {
    "revision": "e62733435b840590b51d",
    "url": "/static/js/58.5d72cb90.chunk.js"
  },
  {
    "revision": "ffd49cf86447de8cea29",
    "url": "/static/js/59.26975cc5.chunk.js"
  },
  {
    "revision": "c2d751b7a0ed5c6c1b1d",
    "url": "/static/js/6.54fbd98f.chunk.js"
  },
  {
    "revision": "f1272c4d6a92d097ba2d",
    "url": "/static/js/60.52a08c51.chunk.js"
  },
  {
    "revision": "eeed23f46b9816861a8d",
    "url": "/static/js/61.c3eddad4.chunk.js"
  },
  {
    "revision": "97d1ee7281aa71516357",
    "url": "/static/js/62.65d044d7.chunk.js"
  },
  {
    "revision": "e1e15eeba9f743e43a2b",
    "url": "/static/js/63.2b3af4eb.chunk.js"
  },
  {
    "revision": "1d744833f071c9e253de",
    "url": "/static/js/64.e043b328.chunk.js"
  },
  {
    "revision": "bf136580f6cfa0e4f673",
    "url": "/static/js/65.eed1c764.chunk.js"
  },
  {
    "revision": "448a7019b64bc056b8cf",
    "url": "/static/js/66.0c56c27a.chunk.js"
  },
  {
    "revision": "c122bb851fda6c755430",
    "url": "/static/js/67.752dcd4e.chunk.js"
  },
  {
    "revision": "3be7758aeaaa7c523cc3",
    "url": "/static/js/68.3dd6fc6c.chunk.js"
  },
  {
    "revision": "10ec270796254a68b627",
    "url": "/static/js/69.60eb509e.chunk.js"
  },
  {
    "revision": "cda9f20689366726472f",
    "url": "/static/js/7.015e55dd.chunk.js"
  },
  {
    "revision": "d9774e5d674f7b020cd6",
    "url": "/static/js/70.213b0e80.chunk.js"
  },
  {
    "revision": "944f10f61cba1e64f426",
    "url": "/static/js/71.ae906e8e.chunk.js"
  },
  {
    "revision": "48bc4b7585b869b9e336",
    "url": "/static/js/72.c2573802.chunk.js"
  },
  {
    "revision": "dd5dbbbc890c4ac2b243",
    "url": "/static/js/73.dffaf2b9.chunk.js"
  },
  {
    "revision": "d86dc941eb5d30249f5b",
    "url": "/static/js/74.04eed27b.chunk.js"
  },
  {
    "revision": "ac8586ce5fa52ed1dc4d",
    "url": "/static/js/75.21f43cce.chunk.js"
  },
  {
    "revision": "e4d5be70d680fb7cae26",
    "url": "/static/js/76.e5ed71b3.chunk.js"
  },
  {
    "revision": "4f3e657b9dd5feb2208e",
    "url": "/static/js/77.ed986df7.chunk.js"
  },
  {
    "revision": "4ee5462901d7eeb1957f",
    "url": "/static/js/78.1d6eb1ba.chunk.js"
  },
  {
    "revision": "4ea343f920a577746a2d",
    "url": "/static/js/79.a85e1a64.chunk.js"
  },
  {
    "revision": "ba49186ddc1bdcf433c8",
    "url": "/static/js/8.134809cb.chunk.js"
  },
  {
    "revision": "e23961015cc411d10ac5",
    "url": "/static/js/80.4e053906.chunk.js"
  },
  {
    "revision": "87349a18e000cd103550",
    "url": "/static/js/9.5ae61bbc.chunk.js"
  },
  {
    "revision": "171d404af0bbd2564a5b",
    "url": "/static/js/main.1cf8ac0b.chunk.js"
  },
  {
    "revision": "5a992cb5ca13d1bf96f5",
    "url": "/static/js/runtime-main.c959eee4.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);